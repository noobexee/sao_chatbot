import pandas as pd

def display_evaluation_results(input_file='test/error_analysis.csv'):
    try:
        df = pd.read_csv(input_file)
        
        if df.empty:
            print("⚠️ The CSV file is empty.")
            return

        # --- 1. PER-QUESTION DISPLAY ---
        print("\n" + "="*85)
        print(f"{'QUESTION':<35} | {'COVERAGE':<9} | {'RECALL':<9} | {'PRECISION':<10} | {'F1 SCORE':<9}")
        print("="*85)
        
        for _, row in df.iterrows():
            # Truncate long questions so the table stays neat
            q_str = str(row['Question'])
            q_short = q_str[:32] + "..." if len(q_str) > 32 else q_str
            
            cov = f"{row['Avg_Coverage_Score']:.1f}%"
            rec = f"{row['Citation_Recall']:.1f}%"
            prec = f"{row['Citation_Precision']:.1f}%"
            f1 = f"{row['Citation_F1']:.1f}%"
            
            print(f"{q_short:<35} | {cov:<9} | {rec:<9} | {prec:<10} | {f1:<9}")
            
        print("="*85)

        # --- 2. GLOBAL AVERAGES SUMMARY ---
        avg_coverage = df['Avg_Coverage_Score'].mean()
        avg_recall = df['Citation_Recall'].mean()
        avg_precision = df['Citation_Precision'].mean()
        avg_f1 = df['Citation_F1'].mean()

        print("\n" + "═"*45)
        print("📊 GLOBAL AVERAGE SCORES")
        print("═"*45)
        print(f"Average Coverage:    {avg_coverage:.2f}%")
        print(f"Citation Recall:     {avg_recall:.2f}%")
        print(f"Citation Precision:  {avg_precision:.2f}%")
        print(f"Citation F1 Score:   {avg_f1:.2f}%")
        print("═"*45 + "\n")

    except FileNotFoundError:
        print(f"❌ Error: {input_file} not found. Please run your evaluation pipeline first.")
    except KeyError as e:
        print(f"❌ Column Name Error: Could not find {e} in the CSV. Make sure you are using the latest error_analysis.csv")

if __name__ == "__main__":
    display_evaluation_results()