import asyncio
import re
import logging

import pandas as pd
from thefuzz import fuzz

from src.app.llm.typhoon import TyphoonLLM
from src.app.chatbot.router import get_legal_sub_route
from src.app.chatbot.retriever.retriever import Retriever
from src.app.chatbot.constants import (
    LEGAL_ROUTE_ORDER,
    LEGAL_ROUTE_GUIDELINE,
    LEGAL_ROUTE_STANDARD,
    LEGAL_ROUTE_REGULATION,
)
from test.merge import get_processed_data

logger = logging.getLogger(__name__)

class RAGEvaluator:

    def __init__(self):
        self._thai_map = str.maketrans('๐๑๒๓๔๕๖๗๘๙', '0123456789')
        self._llm = TyphoonLLM().get_model()
        self._retriever = Retriever()  

    async def run_and_save(
        self,
        input_file: str,
        output_file: str = "detailed_eval_report.csv",
        k: int = 3,
    ) -> None:
        data = get_processed_data(input_file)
        print(f"Starting evaluation on {len(data)} questions using Top-{k} retrieval...")

        rows = [await self._evaluate_question(item, k) for item in data]

        df = pd.DataFrame(rows)
        df.to_csv(output_file, index=False, encoding='utf-8-sig')

        self._print_summary(df, k, output_file)

    async def _evaluate_question(self, item: dict, k: int) -> dict:
        """Runs retrieval and scoring for a single question."""
        query = item['question']
        targets = item['targets']

        print(f"QUESTION: {query}")

        route = await get_legal_sub_route(        
            query=query,
            history=[],
            llm=self._llm,
        )

        retrieved = await self._retrieve(query, route, k)
        top_texts = self._extract_top_texts(retrieved, k)
        hits, found_indices = self._score_hits(retrieved[:k], targets)

        return {
            "Question":  query,
            **top_texts,
            "Context":   " | ".join([t['context'][:100] for t in targets]),
            "Section":   " | ".join([t['section'] for t in targets]),
            "Doc_Name":  " | ".join([t['doc_name'] for t in targets]),
            "Doc_Type":  " | ".join([t['doc_type'] for t in targets]),
            "Hit_Rate":  1 if sum(hits) > 0 else 0,
            "MRR":       self._compute_mrr(hits),
            "Recall":    len(found_indices) / len(targets) if targets else 0,
        }

    async def _retrieve(self, query: str, route: str, k: int) -> list:
        """Picks the correct retriever method based on the legal sub-route."""
        retrievers = {
            LEGAL_ROUTE_ORDER:      lambda: self._retriever.retrieve_order(user_query=query, k=k),
            LEGAL_ROUTE_GUIDELINE:  lambda: self._retriever.retrieve_guideline(user_query=query, k=k),
            LEGAL_ROUTE_STANDARD:   lambda: self._retriever.retrieve_standard(user_query=query, k=k),
            LEGAL_ROUTE_REGULATION: lambda: self._retriever.retrieve_regulation(user_query=query, k=k, history=[]),
        }
        retrieve_fn = retrievers.get(
            route,
            lambda: self._retriever.retrieve_general(user_query=query, k=k)
        )
        return await retrieve_fn()

    def _extract_top_texts(self, retrieved: list, k: int) -> dict:
        """Formats the top-k retrieved chunks into a flat dict for the CSV row."""
        return {
            f"Top_{i+1}_Text": self._format_chunk(retrieved[i]) if len(retrieved) > i else ""
            for i in range(k)
        }

    def _score_hits(
        self, top_k_chunks: list, targets: list
    ) -> tuple[list[int], set[int]]:
        """
        Returns:
            hits:         list of 1/0 per chunk — whether it matched any target
            found_indices: set of target indices that were found
        """
        hits = []
        found_indices: set[int] = set()

        for chunk in top_k_chunks:
            is_hit = False

            for t_idx, target in enumerate(targets):
                if self._is_match(target, chunk):
                    is_hit = True
                    found_indices.add(t_idx)

            for child in chunk.get('related_documents', []):
                for t_idx, target in enumerate(targets):
                    if self._is_match(target, child):
                        is_hit = True
                        found_indices.add(t_idx)

            hits.append(1 if is_hit else 0)

        return hits, found_indices

    @staticmethod
    def _compute_mrr(hits: list[int]) -> float:
        for i, hit in enumerate(hits):
            if hit == 1:
                return 1 / (i + 1)
        return 0.0

    def _is_match(self, target: dict, chunk: dict, threshold: int = 85) -> bool:
        target_txt = self._normalize_text(target.get('context', ''))
        chunk_content = chunk.get('text') or chunk.get('context') or ""
        chunk_txt = self._normalize_text(chunk_content)

        if not target_txt or not chunk_txt:
            return False

        if target_txt in chunk_txt or chunk_txt in target_txt:
            return True

        return fuzz.partial_ratio(target_txt, chunk_txt) >= threshold

    def _format_chunk(self, chunk: dict) -> str:
        """Formats a retrieved chunk and its related documents for the CSV."""
        if not chunk:
            return ""

        lines = [
            f"[{chunk.get('doc_type', 'Unknown')}] "
            f"{chunk.get('law_name', '')} "
            f"({chunk.get('id', '')})",
            chunk.get('text', '') or chunk.get('context', ''),
        ]

        related = chunk.get('related_documents', [])
        if related:
            lines.append("\n--- RELATED DOCS ---")
            for r in related:
                lines.append(
                    f"[{r.get('doc_type', 'Unknown')}] {r.get('law_name', '')}\n"
                    f"{r.get('text', '') or r.get('context', '')}"
                )

        return "\n".join(lines)

    def _normalize_text(self, text: str) -> str:
        if not isinstance(text, str):
            return ""
        text = text.translate(self._thai_map).strip()
        text = re.sub(r'[^ก-๙a-zA-Z0-9]', '', text)
        return text.lower()

    # ------------------------------------------------------------------
    # Output
    # ------------------------------------------------------------------

    @staticmethod
    def _print_summary(df: pd.DataFrame, k: int, output_file: str) -> None:
        print("\n=== METRICS BY DOCUMENT TYPE ===")
        stratified = df.groupby("Doc_Type")[["Hit_Rate", "MRR", "Recall"]].mean().reset_index()
        print(stratified.to_string(index=False))

        print("\n" + "=" * 30)
        print(f"DONE. Saved to {output_file}")
        print(f"Hit Rate@{k}: {df['Hit_Rate'].mean():.4f}")
        print(f"MRR@{k}:      {df['MRR'].mean():.4f}")
        print(f"Recall@{k}:   {df['Recall'].mean():.4f}")
        print("=" * 30)


if __name__ == "__main__":
    evaluator = RAGEvaluator()
    asyncio.run(
        evaluator.run_and_save(
            "test/สำเนาของ SAO_Legal_Template - QA.csv",
            k=3,
        )
    )