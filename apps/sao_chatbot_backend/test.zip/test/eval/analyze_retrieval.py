import pandas as pd

def export_failures(input_file="detailed_eval_report.csv", output_file="failed_cases.csv"):
    try:

        df = pd.read_csv(input_file)

        failures = df[df['Hit_Rate'] == 0].copy()
        
        if failures.empty:
            print("🎉 Amazing! No failures found. Your RAG is perfect (100% Hit Rate).")
            return

        failures.to_csv(output_file, index=False, encoding='utf-8-sig')
        
        print("\n" + "!"*40)
        print(f"FOUND {len(failures)} FAILED QUESTIONS")
        print("!"*40)
        print(f"Full details saved to: {output_file}\n")
        
        print("--- PREVIEW OF WRONG ANSWERS ---")
        for i, row in failures.iterrows():
            print(f"Question: {row['Question']}")
            
            doc_name = str(row['Doc_Name'])[:30] + "..." if len(str(row['Doc_Name'])) > 30 else row['Doc_Name']
            print(f"   Expected: {doc_name} (Section: {row['Section']})")
            top1 = str(row['Top_1_Text']).replace('\n', ' ')[:100]
            if top1 == "nan" or not top1:
                top1 = "[No Result Retrieved]"
            print(f"   AI Found: {top1}...") 
            print("-" * 40)

    except FileNotFoundError:
        print(f"Error: Could not find '{input_file}'. Please run 'eval.py' first.")
    except KeyError as e:
        print(f"Error: Column {e} not found. Make sure you ran the latest 'eval.py' to generate the report.")

if __name__ == "__main__":
    export_failures()