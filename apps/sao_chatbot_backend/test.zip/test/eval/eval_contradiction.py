from typing import Dict, Any
from pydantic import BaseModel, Field
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.prompts import ChatPromptTemplate
from src.app.llm.typhoon import TyphoonLLM
import pandas as pd
import asyncio
import ast

# 1. Define the Schema for Contradiction Logic [cite: 16]
class ContradictionSchema(BaseModel):
    reasoning: str = Field(description="Brief explanation of why the answer contradicts or aligns with the ground truth.")
    is_contradiction: int = Field(description="1 if there is a direct factual disagreement, 0 if it is consistent.")

async def evaluate_contradiction(question: str, ground_truth_context: str, ground_truth_title: str, rag_answer: str) -> Dict[str, Any]:
    """
    Evaluates if the RAG Answer contains information that directly contradicts the Ground Truth.
    Following NitiBench: 0 = Alignment, 1 = Contradiction[cite: 463].
    """
    llm = TyphoonLLM().get_model()
    parser = JsonOutputParser(pydantic_object=ContradictionSchema)
    
    # 2. Construct the Judge Prompt based on NitiBench principles [cite: 16, 461]
    prompt = ChatPromptTemplate.from_template(
        """You are a High-Court Legal Auditor. Your goal is to identify UNAUTHORIZED CLAIMS and FACTUAL DISAGREEMENTS.
        
        [GROUND TRUTH REFERENCE]
        - Source: {title}
        - Content: {context}

        [STRICT AUDIT RULES]
        1. FACTUAL DISAGREEMENT (Score 1): The RAG Answer provides a rule, deadline, or condition that is opposite or different from the Ground Truth. (Example: Truth says '7 days', Answer says '30 days').
        2. UNAUTHORIZED SPECIFICITY (Score 1): If the RAG Answer mentions a specific Section Number, Penalty Amount, or Law Name that is NOT found in the provided Ground Truth, it is a contradiction. We assume the Context is the ONLY source of truth.
        3. PROCEDURAL ERROR (Score 1): The Answer describes a legal process step that contradicts the sequence or requirements in the Reference.
        4. CONSISTENCY (Score 0): The answer is strictly derived from the Reference OR correctly states it cannot answer due to lack of information.

        QUESTION: {question}
        RAG ANSWER: {answer}
        
        {format_instructions}"""
    )
    try:
        res = await (prompt | llm | parser).ainvoke({
            "question": question, 
            "context": ground_truth_context, 
            "title": ground_truth_title,
            "answer": rag_answer, 
            "format_instructions": parser.get_format_instructions()
        })
        
        score = float(res.get("is_contradiction", 1)) 
        return {
            "score": score, 
            "reason": res.get("reasoning", ""), 
            "status": "CONTRADICTED" if score == 1.0 else "CONSISTENT"
        }
    except Exception as e:
        return {"score": 1.0, "reason": f"Error in Contradiction Eval: {str(e)}", "status": "ERROR"}
    

# Helper to handle string-encoded lists in CSV
def parse_list(val):
    if isinstance(val, str) and val.startswith('['):
        try:
            return ast.literal_eval(val)
        except:
            return [val]
    return [val] if not isinstance(val, list) else val

async def run_evaluation():
    # Load your prepared data
    df = pd.read_csv('test/prepared_data.csv')
    
    results = []
    
    for index, row in df.iterrows():
        # Prepare inputs
        question = row['question']
        rag_answer = row['answer']
        
        # Merge multi-label context into one block for the judge
        contexts = parse_list(row['context'])
        titles = parse_list(row['doc_title'])
        
        merged_context = "\n---\n".join(contexts)
        merged_titles = ", ".join(titles)
        
        # Call the Contradiction Judge
        eval_result = await evaluate_contradiction(
            question=question,
            ground_truth_context=merged_context,
            ground_truth_title=merged_titles,
            rag_answer=rag_answer
        )
        
        # Append score and reasoning back to your data
        results.append({
            "question": question,
            "contradiction_score": eval_result['score'],
            "reason": eval_result['reason'],
            "status": eval_result['status'],
            "rag_answer" : rag_answer,
            "ground_truth" : merged_context
        })

    # Save results to a new CSV
    pd.DataFrame(results).to_csv('test/contradiction_evaluation_results.csv', index=False)
    print("Evaluation Complete. Results saved to evaluation_results.csv")

# Run the process
if __name__ == "__main__":
    asyncio.run(run_evaluation())