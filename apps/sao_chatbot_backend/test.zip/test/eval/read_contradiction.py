import pandas as pd

def show_contradiction_summary(df):
    # Calculate the percentage of responses that contradicted the ground truth
    total_samples = len(df)
    total_contradictions = df['contradiction_score'].sum()
    contradiction_rate = (total_contradictions / total_samples) * 100
    
    print(f"--- Evaluation Summary ---")
    print(f"Total Samples: {total_samples}")
    print(f"Total Contradictions: {total_contradictions}")
    print(f"Contradiction Rate: {contradiction_rate:.2f}%")
    
    return contradiction_rate

df = pd.read_csv("test/contradiction_evaluation_results.csv")
print(show_contradiction_summary(df))