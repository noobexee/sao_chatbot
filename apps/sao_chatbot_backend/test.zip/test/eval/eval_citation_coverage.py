import pandas as pd
import asyncio
import re
import ast
from typing import List, Optional, Tuple, Dict, Any
from pydantic import BaseModel, Field
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from difflib import SequenceMatcher

from src.app.chatbot.handlers.legal_query import LegalRagHandler
from src.app.chatbot.retriever import Retriever
from src.app.llm.typhoon import TyphoonLLM

def calculate_similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()

def normalize_and_clean(text: str) -> str:
    """Translates Thai numbers to Arabic and removes ALL spaces."""
    if not text or str(text).lower() == "nan": 
        return ""
    text = str(text).translate(str.maketrans('๐๑๒๓๔๕๖๗๘๙', '0123456789'))
    return re.sub(r'\s+', '', text)

def bi_directional_match(expected_title: str, expected_section: str, rag_ref: str) -> bool:
    """NEW LOGIC: Strict bi-directional substring match + Similarity + Document ID Fallback."""
    sec_str = str(expected_section) if str(expected_section).lower() != 'nan' else ""
    expected_full = f"{expected_title}{sec_str}"
    
    clean_expected = normalize_and_clean(expected_full)
    clean_rag = normalize_and_clean(rag_ref)
    
    if not clean_expected or not clean_rag:
        return False
        
    if len(clean_rag) < 10 or len(clean_expected) < 10:
        return clean_expected == clean_rag
        
    if (clean_expected in clean_rag) or (clean_rag in clean_expected):
        return True
        
    if len(clean_expected) > 40 and len(clean_rag) > 40:
        sim_score = calculate_similarity(clean_expected, clean_rag)
        if sim_score >= 0.85:
            return True
        
    id_expected = re.search(r'\d+/\d{4}', clean_expected)
    id_rag = re.search(r'\d+/\d{4}', clean_rag)
    
    if id_expected and id_rag and (id_expected.group(0) == id_rag.group(0)):
        if "คำสั่ง" in expected_title and "คำสั่ง" in rag_ref:
            return True
        if "ประกาศ" in expected_title and "ประกาศ" in rag_ref:
            return True
            
    return False

def pure_thai_title(text: str) -> str:
    """OLD LOGIC: Strips everything except core Thai/English letters."""
    if not text or pd.isna(text): return ""
    text = str(text).replace('พ.ศ.', '').replace('ฉบับที่', '')
    return re.sub(r'[^ก-๙a-zA-Z]', '', text)

def section_number_match(gold_sec: str, current_ref: str, all_refs: List[str]) -> bool:
    """OLD LOGIC: Finds if the section number exists, supporting global fallback."""
    if not gold_sec or str(gold_sec).lower() == "nan": return True
    gold_num = re.sub(r'\D', '', str(gold_sec))
    if not gold_num: return True
    
    rag_arabic = str(current_ref).translate(str.maketrans('๐๑๒๓๔๕๖๗๘๙', '0123456789'))
    rag_nums = re.findall(r'\d+', rag_arabic)
    
    if gold_num in rag_nums:
        return True
        
    combined_refs = " ".join(all_refs).translate(str.maketrans('๐๑๒๓๔๕๖๗๘๙', '0123456789'))
    all_nums = re.findall(r'\d+', combined_refs)
    
    return gold_num in all_nums

def parse_grouped_column(value: str) -> List[str]:
    if not value or pd.isna(value): return []
    try:
        parsed = ast.literal_eval(str(value))
        if isinstance(parsed, (list, set, tuple)):
            return [str(i) for i in parsed]
    except:
        return [i.strip() for i in str(value).split(',')]
    return [str(value)]

class AtomicCoverageSchema(BaseModel):
    coverage_level: str = Field(description="FULL_COVERAGE, PARTIAL_COVERAGE, or NO_COVERAGE")
    reasoning: str = Field(description="Detailed explanation in English or Thai.")

async def evaluate_atomic_coverage(question: str, atomic_context: str, atomic_title: str, atomic_section: str, rag_answer: str) -> Dict[str, Any]:
    llm = TyphoonLLM().get_model()
    parser = JsonOutputParser(pydantic_object=AtomicCoverageSchema)
    
    prompt = ChatPromptTemplate.from_template(
        """You are a Senior Legal Auditor. Evaluate if the RAG Answer covers this specific legal unit.
        
        [GROUND TRUTH UNIT]
        - Source: {title} | Section: {section}
        - Rule: {context}

        [EVALUATION RULES]
        1. NUMBER EQUIVALENCE: Thai numerals (๑, ๒, ๓) and Arabic numerals (1, 2, 3) are strictly equal.
        2. VERSION AGNOSTIC (CRITICAL): Ignore differences in the year (พ.ศ.) or amendment version (ฉบับที่) between the Ground Truth and RAG Answer. As long as the core law name and section number match, the attribution is CORRECT. Do not penalize the RAG for providing newer versions or additional relevant legal context.
        3. FULL_COVERAGE: All core facts, steps, and conditions of the Ground Truth Rule are present in the answer and attributed to the correct core law and section.
        4. PARTIAL_COVERAGE: The RAG answer contains some of the main points from the Ground Truth Rule, but misses key conditions, exceptions, or specific details.
        5. NO_COVERAGE: The fact is entirely missing, completely wrong, or attributed to the WRONG section number.

        RAG ANSWER: {answer}
        {format_instructions}"""
    )
    
    try:
        res = await (prompt | llm | parser).ainvoke({
            "question": question, "context": atomic_context, "title": atomic_title,
            "section": atomic_section, "answer": rag_answer, "format_instructions": parser.get_format_instructions()
        })
        level = res.get("coverage_level")
        score = 100.0 if level == "FULL_COVERAGE" else 50.0 if level == "PARTIAL_COVERAGE" else 0.0
        return {"score": score, "reason": res.get("reasoning", ""), "unit": f"{atomic_title} {atomic_section}"}
    except Exception as e:
        return {"score": 0.0, "reason": f"Error in LLM Eval: {str(e)}", "unit": f"{atomic_title} {atomic_section}"}

# --- EVALUATION LOGIC ---
    
def run_citation_eval(doc_types: List[str], titles: List[str], sections: List[str], rag_ref_names: List[str]) -> Tuple[float, float, float, List[Dict]]:
    cit_details = []
    tp = 0
    fn = 0
    matched_rag_refs = set()

    # STRIPPER: Remove anything inside () and remove the word 'วรรค' + numbers following it
    clean_all_refs_for_sec = [re.sub(r'วรรค\s*[๐๑๒๓๔๕๖๗๘๙0-9]*', '', re.sub(r'\([^)]*\)', '', str(r))) for r in rag_ref_names]

    for g_type, g_title, g_section in zip(doc_types, titles, sections):
        found = False
        g_title_str = str(g_title)
        g_type_str = str(g_type)
        
        # Check if this document is a Regulation
        is_order_or_ann = "คำสั่ง" in g_title_str or "ประกาศ" in g_title_str or "คำสั่ง" in g_type_str or "ประกาศ" in g_type_str
        is_regulation = ("ระเบียบ" in g_type_str or "ระเบียบ" in g_title_str) and not is_order_or_ann

        if is_regulation:
            g_title_pure = pure_thai_title(g_title)

            for i, ref in enumerate(rag_ref_names):
                ref_pure = pure_thai_title(ref)
                title_match = (g_title_pure in ref_pure) or (calculate_similarity(g_title_pure, ref_pure) >= 0.85)
                
                clean_ref_for_sec = clean_all_refs_for_sec[i]
                sec_match = section_number_match(g_section, clean_ref_for_sec, clean_all_refs_for_sec)
                
                if title_match and sec_match:
                    found = True
                    matched_rag_refs.add(i)
                    break 
        else:
            g_title_stripped = re.sub(r'ข้อ\s*[๐๑๒๓๔๕๖๗๘๙0-9]+', '', str(g_title)).strip()
            
            for i, ref in enumerate(rag_ref_names):
                if bi_directional_match(g_title_stripped, "", ref):
                    found = True
                    matched_rag_refs.add(i)
                    break 
                
        if found:
            tp += 1
            cit_details.append({"unit": f"{g_title} {g_section}", "status": "HIT"})
        else:
            fn += 1
            cit_details.append({"unit": f"{g_title} {g_section}", "status": "MISS"})

    fp = len(rag_ref_names) - len(matched_rag_refs)

    recall = (tp / (tp + fn)) * 100.0 if (tp + fn) > 0 else 0.0
    precision = (tp / (tp + fp)) * 100.0 if (tp + fp) > 0 else 0.0
    f1_score = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0

    return recall, precision, f1_score, cit_details

async def evaluate_single_turn(question, context_raw, doc_type_raw, title_raw, section_raw, rag_answer, rag_ref_names):
    contexts = parse_grouped_column(context_raw)
    doc_types = parse_grouped_column(doc_type_raw)
    titles = parse_grouped_column(title_raw)
    sections = parse_grouped_column(section_raw)
    
    max_len = max(len(contexts), len(titles), len(sections), len(doc_types))
    while len(contexts) < max_len: contexts.append(contexts[-1] if contexts else "")
    while len(doc_types) < max_len: doc_types.append(doc_types[-1] if doc_types else "")
    while len(titles) < max_len: titles.append(titles[-1] if titles else "")
    while len(sections) < max_len: sections.append("nan")

    cov_results = await asyncio.gather(*[evaluate_atomic_coverage(question, contexts[i], titles[i], sections[i], rag_answer) for i in range(max_len)])
    avg_coverage = sum(r['score'] for r in cov_results) / len(cov_results) if cov_results else 0.0
    
    recall, precision, f1_score, cit_details = run_citation_eval(doc_types, titles, sections, rag_ref_names)

    return {
        "coverage": avg_coverage, 
        "citation_recall": recall,
        "citation_precision": precision,
        "citation_f1": f1_score,
        "raw_coverage_list": cov_results, 
        "raw_citation_list": cit_details,
        "expected_titles": titles, 
        "expected_sections": sections
    }

def aggregate_results(all_data: List[Dict]) -> pd.DataFrame:
    rows = []
    for entry in all_data:
        cov_scores = [res['score'] for res in entry['detailed_coverage']]
        avg_cov = sum(cov_scores) / len(cov_scores) if cov_scores else 0
        
        expected_cites = [f"{t} {s}" for t, s in zip(entry['expected_titles'], entry['expected_sections'])]
        cit_statuses = [f"{res['unit']}: {res['status']}" for res in entry['detailed_citation']]

        rows.append({
            "Question": entry['question'],
            "RAG_Answer": entry['rag_answer'],
            
            "Avg_Coverage_Score": avg_cov,
            "Citation_Recall": entry['citation_recall'],
            "Citation_Precision": entry['citation_precision'],
            "Citation_F1": entry['citation_f1'],
            
            "Expected_Citations": "| ".join(expected_cites),
            "RAG_Citations": "| ".join(entry['rag_ref_names']),
            "Citation_Hit_Miss_Log": "| ".join(cit_statuses),
            "Coverage_Reasons": "| ".join([res['reason'] for res in entry['detailed_coverage']])
        })
    return pd.DataFrame(rows)

async def run_pipeline(input_csv: str, output_csv: str, error_analysis_csv: str):
    df = pd.read_csv(input_csv)
    llm_rag, retriever = TyphoonLLM().get_model(), Retriever()
    all_eval_data = []
    legal_query = LegalRagHandler(retriever=retriever)

    for idx, row in df.iterrows():
        print(f"Processing Row {idx+1}/{len(df)}...")
        
        raw_ans, raw_refs = await legal_query.handle(row['question'], [], llm_rag)
        
        ans = raw_ans[1] if isinstance(raw_ans, tuple) else raw_ans
        refs_dict = raw_refs[1] if isinstance(raw_refs, tuple) else raw_refs
        
        if isinstance(refs_dict, dict):
            rag_ref_names = list(refs_dict.keys())
        else:
            rag_ref_names = []

        metrics = await evaluate_single_turn(
            row['question'], 
            row['context'], 
            row.get('doc_type', ''), 
            row['doc_title'], 
            row['section'], 
            ans, 
            rag_ref_names
        )
        
        all_eval_data.append({
            **metrics, 
            "question": row['question'], 
            "rag_answer": ans, 
            "rag_ref_names": rag_ref_names, 
            "detailed_coverage": metrics['raw_coverage_list'], 
            "detailed_citation": metrics['raw_citation_list']
        })

    summary_df = pd.DataFrame(all_eval_data).drop(columns=[
        'detailed_coverage', 'detailed_citation', 'raw_coverage_list', 
        'raw_citation_list', 'expected_titles', 'expected_sections'
    ])
    summary_df.to_csv(output_csv, index=False, encoding='utf-8-sig')

    agg_df = aggregate_results(all_eval_data)
    agg_df.to_csv(error_analysis_csv, index=False, encoding='utf-8-sig')
    
    print(f"Pipeline complete. Error Analysis saved to: {error_analysis_csv}")

if __name__ == "__main__":
    asyncio.run(run_pipeline('test/prepared_data.csv', 'test/eval_results.csv', 'test/error_analysis.csv'))