import pandas as pd

def get_processed_data(file_path):

    df = pd.read_csv(file_path)
    
    df['no'] = df['no'].ffill()
    df['question'] = df['question'].ffill()

    processed_questions = []

    for q_text, group in df.groupby('question'):
        targets = []
        for _, row in group.iterrows():
            targets.append({
                "doc_type": str(row.get('doc_type', '')).strip(),
                "doc_name": str(row.get('doc_title', '')).strip(),
                "section": str(row.get('section', '')).strip(),
                "context": str(row.get('context', '')).strip(),
                "answer": str(row.get('answer', '')).strip() 
            })
        
        processed_questions.append({
            "question": q_text,
            "targets": targets
        })
            
    return processed_questions