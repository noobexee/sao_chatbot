import asyncio
from src.app.chatbot.chatbot import Chatbot
from src.app.chatbot.retriever import Retriever
from src.app.chatbot.route_handlers import get_legal_route, handle_legal_rag
from src.app.llm.typhoon import TyphoonLLM

async def main():
    retriever = Retriever()
    user_query = "  "
    llm = TyphoonLLM().get_model()
    route = await get_legal_route(query=user_query, history_messages=[], llm=llm)
    print("ROUTE : ")
    print(route)

    if route == "ORDER":
        retrieved = await retriever.retrieve_order(user_query=user_query, k=3)
    elif route == "GUIDELINE":
        retrieved = await retriever.retrieve_guideline(user_query=user_query, k=3)
    elif route == "STANDARD":
        retrieved = await retriever.retrieve_standard(user_query=user_query, k=3)
    elif route == "REGULATION":
        retrieved = await retriever.retrieve_regulation(user_query=user_query, k=3, history=[])
    else:
        retrieved = await retriever.retrieve_general(query=user_query, k=3)
    print(retrieved)

async def main2():
    retriever = Retriever()
    user_query = "การชี้แจงเหตผลและแสดงพยานหลักฐานของผู้รับตรวจ หรือเจ้าหน้าที่หน่วยรับตรวจ ให้ดำเนินการอย่างไร"
    llm = TyphoonLLM().get_model()
    ans = await handle_legal_rag(user_query, [], llm, retriever)
    print(ans)


if __name__ == "__main__":
    asyncio.run(main())