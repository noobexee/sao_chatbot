import os

def check_for_docker_safety(target_path, filename_limit=100):
    abs_target = os.path.abspath(target_path)
    # Average length of Docker's internal overlayfs prefix
    DOCKER_PREFIX_BUFFER = 120 
    SYSTEM_MAX = 250 # The danger zone

    print(f"--- Docker Safety Scan ---")
    print(f"Target: {abs_target}\n")

    found_risk = 0
    for root, dirs, files in os.walk(abs_target):
        # Get the path relative to your project folder
        rel_dir = os.path.relpath(root, abs_target)
        
        for name in files:
            # 1. Check filename length (Thai characters are heavy)
            name_len = len(name)
            
            # 2. Estimate what the path will look like inside Docker's layers
            # Structure: [Docker Prefix] + [Your internal folder structure] + [Filename]
            estimated_total = DOCKER_PREFIX_BUFFER + len(rel_dir) + name_len
            
            if estimated_total > SYSTEM_MAX or name_len > filename_limit:
                found_risk += 1
                print(f"❌ RISK FOUND")
                print(f"   File: {name}")
                print(f"   Filename Length: {name_len}")
                print(f"   Est. Docker Path Length: ~{estimated_total} (Limit is {SYSTEM_MAX})")
                print("-" * 30)

    if found_risk == 0:
        print("✅ Your files look safe for Docker!")
    else:
        print(f"Found {found_risk} files that will likely fail in Docker.")

# Set your folder here
target = "./scripts/files_n_data"
check_for_docker_safety(target)