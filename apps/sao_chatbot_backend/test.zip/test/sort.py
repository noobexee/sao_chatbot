import json
import re

def natural_sort_key(key):
    """
    Extracts numbers from the string 'ข้อ X (Y)' to return a list [X, Y].
    This allows Python to sort numerically instead of alphabetically.
    """
    # Finds all digit sequences: "ข้อ 26 (1)" -> [26, 1]
    return [int(s) for s in re.findall(r'\d+', key)]

def sort_json_file(input_filename, output_filename):
    try:
        # 1. Read the JSON file
        with open(input_filename, 'r', encoding='utf-8') as f:
            data = json.load(f)

        # 2. Iterate through each main category (like "ระเบียบสำนักงาน...")
        sorted_data = {}
        for main_title, sections in data.items():
            # Sort the keys (ข้อ) using our natural_sort_key function
            sorted_keys = sorted(sections.keys(), key=natural_sort_key)
            
            # Reconstruct the inner dictionary in the new order
            sorted_sections = {k: sections[k] for k in sorted_keys}
            sorted_data[main_title] = sorted_sections

        # 3. Write the sorted data to a new file
        with open(output_filename, 'w', encoding='utf-8') as f:
            json.dump(sorted_data, f, indent=4, ensure_ascii=False)
            
        print(f"Success! Sorted file saved as: {output_filename}")

    except FileNotFoundError:
        print("Error: The input file was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

# --- Execution ---
# Replace 'input.json' with your actual filename
sort_json_file('storage/master_map.json', 'sorted_output.json')