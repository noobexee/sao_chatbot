import asyncio
from src.app.chatbot.route_handlers import handle_legal_rag
from src.app.llm.typhoon import TyphoonLLM
from src.app.chatbot.chatbot import Chatbot
from src.app.chatbot.retriever import Retriever

async def main():
    llm_rag, retriever = TyphoonLLM().get_model(), Retriever()
    ans, refs_dict = await handle_legal_rag("การกำหนดประเด็นการตรวจสอบเรื่องที่ผู้ว่าการสั่งการให้ตรวจสอบเฉพาะกรณี ให้ดำเนินการอย่างไร", [], llm_rag, retriever)
    print(ans)
    print(refs_dict)


if __name__ == "__main__":
    asyncio.run(main())