import pandas as pd

def print_final_metrics(file_path):
    try:
        # Read the CSV with the same encoding used in your evaluator
        df = pd.read_csv(file_path, encoding='utf-8-sig')

        # --- GLOBAL METRICS ---
        mean_hit_rate = df['Hit_Rate'].mean()
        mean_recall = df['Recall'].mean()
        mean_mrr = df['MRR'].mean()
    
        print("="*40)
        print(f"OVERALL PERFORMANCE ({len(df)} Questions)")
        print("-" * 40)
        print(f"Hit Rate:   {mean_hit_rate * 100:.2f}%")
        print(f"Recall:     {mean_recall * 100:.2f}%")
        print(f"MRR Score:  {mean_mrr:.4f}")
        print("="*40)

        # --- STRATIFIED METRICS (BY DOC TYPE) ---
        print("\nMETRICS BY DOCUMENT TYPE")
        print("-" * 40)
        
        # In case some rows have multiple types (e.g., "Type A | Type B"), 
        # this grouping uses the string as-is. 
        stratified = df.groupby("Doc_Type")[["Hit_Rate", "Recall", "MRR"]].mean()
        
        # Formatting for display: Convert decimals to percentages for HR and Recall
        display_df = stratified.copy()
        display_df['Hit_Rate'] = display_df['Hit_Rate'].map(lambda x: f"{x*100:.2f}%")
        display_df['Recall'] = display_df['Recall'].map(lambda x: f"{x*100:.2f}%")
        display_df['MRR'] = display_df['MRR'].map(lambda x: f"{x:.4f}")
        
        print(display_df.to_string())
        print("="*40)

    except FileNotFoundError:
        print(f"Error: Could not find file '{file_path}'")
    except KeyError as e:
        print(f"Error: The file is missing a required column: {e}")

if __name__ == "__main__":
    print_final_metrics("detailed_eval_report.csv")