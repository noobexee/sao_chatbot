import pandas as pd
import os

def rename_triple_sync(csv_path, old_full_path, new_full_path):
    # --- DEBUGGING: Print current location ---
    print(f"Current Working Directory: {os.getcwd()}")
    print(f"Looking for PDF at: {os.path.abspath(old_full_path)}")
    
    old_filename_ext = os.path.basename(old_full_path)
    new_filename_ext = os.path.basename(new_full_path)
    
    # Get base names for CSV (Removes ".pdf")
    old_csv_val = os.path.splitext(old_filename_ext)[0]
    new_csv_val = os.path.splitext(new_filename_ext)[0]
    
    # 2. PHYSICAL RENAME: PDF
    if os.path.exists(old_full_path):
        os.rename(old_full_path, new_full_path)
        print(f"✅ Physical PDF renamed: {new_filename_ext}")
    else:
        print(f"❌ Error: PDF not found at {old_full_path}")
        return

    # 3. PHYSICAL RENAME: TXT
    old_txt_path = os.path.splitext(old_full_path)[0] + ".txt"
    new_txt_path = os.path.splitext(new_full_path)[0] + ".txt"
    
    if os.path.exists(old_txt_path):
        os.rename(old_txt_path, new_txt_path)
        print(f"✅ Physical TXT renamed: {os.path.basename(new_txt_path)}")
    else:
        print(f"⚠️ Note: TXT not found ({os.path.basename(old_txt_path)})")

    # 4. CSV UPDATE
    # Make sure csv_path is correct relative to where you run the script
    if not os.path.exists(csv_path):
        print(f"❌ Error: CSV file not found at {csv_path}")
        return

    df = pd.read_csv(csv_path)
    
    if old_csv_val in df['pdf_file_path'].values:
        df.loc[df['pdf_file_path'] == old_csv_val, 'pdf_file_path'] = new_csv_val
        df.to_csv(csv_path, index=False, encoding='utf-8-sig')
        print(f"✅ CSV updated: '{old_csv_val}' -> '{new_csv_val}'")
    else:
        print(f"❌ Warning: '{old_csv_val}' not found in CSV column 'pdf_file_path'")

# --- EXECUTION ---
# Based on your terminal: sao_chatbot_backend is the root.
# If your CSV is inside 'scripts', the path should be:
csv_file = "scripts/data.csv" 

# Adjust these paths if you are already inside the scripts folder
old_p = "storage/files/ระเบียบสำนักงานการตรวจเงินแผ่นดินว่าด้วยการปฏิบัติหน้าที่ของเจ้าหน้าที่ที่ได้รับมอบหมาย พ.ศ.2562.pdf"
new_p = "storage/files/ระเบียบว่าด้วยการปฏิบัติหน้าที่ของเจ้าหน้าที่ที่ได้รับมอบหมาย พ.ศ.2562.pdf"

rename_triple_sync(csv_file, old_p, new_p)
